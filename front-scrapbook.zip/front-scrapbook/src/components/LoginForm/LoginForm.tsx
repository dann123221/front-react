import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import { Form } from "./style";
import Button from "@mui/material/Button";
import Link from "@mui/material/Link";
import Box from "@mui/material/Box";
import { useForm } from "../../hooks/useForm";
import { loginUser } from "../../services/api";
import { toast } from "react-toastify";
import { useNavigate } from 'react-router-dom';

export function LoginForm() {
  const initialState = {
    name: "",
    password: "",
  };
  
  const { onChange, onSubmit, values } = useForm(
    loginUserCallback,
    initialState
    );
    
    const navigate = useNavigate();
    async function loginUserCallback() {
      loginUser(values).then((response) => {
        localStorage.setItem("token", `${response.token}`);
        const logged = response.logged;
        
        if (logged) {
        toast.success(response.message);
        return navigate('/scrapbook');
      } else {
        toast.error(response.message);
      }
    });
  }

  return (
    <>
      <Box width={"400px"} maxWidth={"500px"}>
        <Form onSubmit={onSubmit}>
          <TextField
            id="name"
            name="name"
            label="Name"
            variant="filled"
            onChange={onChange}
            required
            sx={{ marginBottom: 5 }}
          />
          <TextField
            id="password"
            name="password"
            label="Password"
            variant="filled"
            type="password"
            onChange={onChange}
            required
          />
          <Button variant="outlined" sx={{ p: 2, marginTop: 3 }} type="submit">
            Login
          </Button>
        </Form>
        <Box
          component="div"
          sx={{
            display: "flex",
            p: 2,
            justifyContent: "center",
          }}
        >
          <Typography variant="body1" component="p" align="center">
            Don't have an account?{" "}
            <Link href="#" underline="hover">
              Register
            </Link>
          </Typography>
        </Box>
      </Box>
    </>
  );
}
