import { useState } from "react";
import { User } from "./../components/models/userModel";

export const useForm = (callback: any, initialState = {}) => {
  const [values, setValues] = useState<User>({ name: "", password: "" });

  const onChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValues({ ...values, [event.target.name]: event.target.value });
  };

  const onSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    await callback();
  };

  return {
    onChange,
    onSubmit,
    values,
  };
};
