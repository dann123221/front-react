import axios from "axios";
import { User } from "./../components/models/userModel";
axios.defaults.baseURL = "http://localhost:8081";

const loginUser = async (user: User) => {
  const response = await axios.post("/auth", user);

  return response.data;
};

const authUser = async (token: string) => {
  const response = await axios.get("/user", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  return response.data;
};
  
const errands = async (id: string) => {
  const response = await axios.get(`/errand/${id}`)

  return response.data
}

export { loginUser, authUser, errands };
