import { Box } from "@mui/material";
import BasicTable from "../../components/Table/Table";
import { errands } from "../../services/api";

console.log(errands('1'));

export default function ScrapBook() {
    return (
    <>
    <Box sx={{
        p: '2rem',
        backgroundColor: 'green',
    }}>
        {/* <BasicTable /> */}
        <h1>WORKING IN PROGRESS</h1>
        <h1>WORKING IN PROGRESS</h1>
        <h1>WORKING IN PROGRESS</h1>
    </Box>
        
    </>)
}