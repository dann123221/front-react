import { LoginForm } from "../../components/LoginForm/LoginForm";
import styled from "styled-components";
import { Box, Typography } from "@mui/material";

const BackGround = styled.div`
  width: 100%;
  height: 100vh;
  background-size: cover;
  background-position: center;
  background-image: url("https://images5.alphacoders.com/100/1000939.jpg");
`;

export default function Login() {
  return (
    <>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
        }}
      >
        <BackGround />
        <Box
          sx={{
            width: "100%",
          }}
        >
          <Box
            sx={{
              padding: "5rem",
              display: "flex",
              alignItems: "center",
              flexDirection: "column",
            }}
          >
            <Typography
              variant="h3"
              sx={{
                textAlign: "center",
                paddingBottom: "2rem",
              }}
            >
              ScrapBook
            </Typography>
            <LoginForm />
          </Box>
        </Box>
      </Box>
    </>
  );
}
